#!/bin/bash

echo "helllo i did something"
